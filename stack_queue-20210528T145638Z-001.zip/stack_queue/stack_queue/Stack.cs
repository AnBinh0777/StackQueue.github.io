﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stack_queue
{
	public class Stack
	{
		Cphanso[] ds;
		int spt;
		public Stack()
		{
			ds = new  Cphanso[100];
			spt = 0;
		}

		public string XuatDanhSach()
		{
			string s = "";
			for (int i = 0; i < spt; i++)
			{
				s += ds[i].Xuatphanso() + "\n";
			}
			return s;
		}
		public Cphanso LayCuoi()
		{
			Cphanso ps = new Cphanso(0, 1);
			ps = ds[spt - 1];
			return ps;

		}
		public void Push(Cphanso ps)
		{
			ds[spt] = ps;
			spt++;
		}
		public void Pop()
		{
			ds[spt - 1] = null;
			spt--;
		}
	}
}
