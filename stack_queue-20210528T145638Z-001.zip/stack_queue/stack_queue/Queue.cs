﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stack_queue
{
	public class Queue
	{
		Cphanso[] ds;
		int spt;
		public Queue()
		{
			ds = new Cphanso[100];
			spt = 0;
		}

		public string XuatDanhSach()
		{
			string s = "";
			for (int i = 0; i < spt; i++)
			{
				s += ds[i].Xuatphanso() + "\n";
			}
			return s;
		}
		public void Push(Cphanso ps)
		{
			ds[spt] = ps;
			spt++;
		}

		public void Pop()
		{
			for (int i = 0; i < spt - 1; i++)
			{
				ds[i] = ds[i + 1];
			}
			spt--;
		}
		public Cphanso LayCuoi()
		{
			Cphanso ps = new Cphanso(0, 1);
			ps = ds[0];
			return ps;

		}
	}
}
