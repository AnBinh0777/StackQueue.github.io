﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace stack_queue
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
			st = new Stack();
			qu = new Queue();
		}
		Stack st;
		Queue qu;
		private void Btnthemstack_Click(object sender, RoutedEventArgs e)
		{
			Cphanso phanso = new Cphanso(int.Parse(txttu.Text), int.Parse(txtmau.Text));
			st.Push(phanso);
			txtdanhsach.Text = st.XuatDanhSach();
		}

		private void Btnlaystack_Click(object sender, RoutedEventArgs e)
		{
			txtlayra.Text = st.LayCuoi().Xuatphanso() + "\n";
			st.Pop();
			txtdanhsach.Text = st.XuatDanhSach();
		}

		private void Btnthemqueue_Click(object sender, RoutedEventArgs e)
		{
			Cphanso phanso = new Cphanso(int.Parse(txttu.Text), int.Parse(txtmau.Text));
			qu.Push(phanso);
			txtdanhsach.Text = qu.XuatDanhSach();
		}

		private void Btnlayqueue_Click(object sender, RoutedEventArgs e)
		{
			txtlayra.Text = qu.LayCuoi().Xuatphanso() + "\n";
			qu.Pop();
			txtdanhsach.Text = qu.XuatDanhSach();
		}
	}
}
