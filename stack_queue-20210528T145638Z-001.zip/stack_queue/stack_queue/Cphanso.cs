﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stack_queue
{
	public class Cphanso
	{
		public int tu;
		public int mau;
		public Cphanso()
		{
			tu = 0;
			mau = 1;
		}
		public Cphanso(int tuso, int mauso)
		{
			tu = tuso;
			mau = mauso;
		}
		public string Xuatphanso()
		{
			if (tu == mau)
			{
				return "1";
			}
			else
			{
				if (tu == 0)
				{
					return "0";
				}
				else
				{
					if (mau == 1)
					{
						return tu + "";
					}
					else
					{
						if (tu > 0 && mau > 0 || tu < 0 && mau < 0)
						{
							int a = Math.Abs(tu);
							int b = Math.Abs(mau);
							return a + "/" + b;
						}
						else
						{
							int a = Math.Abs(tu);
							int b = Math.Abs(mau);
							return -a + "/" + b;
						}
					}

				}
			}
		}
	}
}
